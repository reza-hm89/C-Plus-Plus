// mxmail.cpp : Defines the entry point for the console application.
// Author: David Luu
// Last modified: 08/29/06
// Contact: tools@parsingprose.com
// http://www.parsingprose.com

// MX Mailer v1.0
// Send mail directly to recipient's mail server via DNS MX lookup,
// bypassing need for authentication for sending mail out of internal network.
// Based on Code Project article, "Send mail without specifying an SMTP server"
// by Nishant Sivakumar, http://www.codeproject.com/tips/CSMTPConnection2.asp

#include "stdafx.h"
//header file for mail via MX mail server lookup
#include "smtpconnection2.h"
#include <string>
#include <fstream>
using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	//no arguments, not enough, or too many = incorrect use
	if((argc < 7) || (argc > 7)){
		cout << endl;
		cout << "MX Mailer v1.0" << endl;
		cout << "Tool written by David Luu, tools@parsingprose.com" << endl;
		cout << "Send mail directly to recipient's mail server via DNS MX lookup," << endl;
		cout << "bypassing need for authentication for sending mail out of internal network." << endl;
		cout << endl;
		cout << "Usage:" << endl;
		cout << "------" << endl;
		cout << "mxmail from_name from_addr to_addr subject msgflag msgTxt_or_pathToMsgTxtFile" << endl;
		cout << endl;
		cout << "msgflag: -t next parameter is the message inside quotes" << endl;
		cout << "         -f next parameter is the path to text file containing" << endl;
		cout << "            the message. Use quotes if path has spaces in it, etc." << endl;
		cout << endl;
		cout << "Examples:" << endl;
		cout << "---------" << endl;
		cout << "mxmail \"Your Name\" you@company.com someone@company2.com \"The subject\" -t \"The message\"" << endl;
		cout << endl;
		cout << "mxmail \"Your Name\" you@company.com someone@company2.com \"The subject\" -f \"C:\\temp\\message.txt\"" << endl;
		cout << endl;
		cout << "Based on Code Project article, \"Send mail without specifying an SMTP server\"" << endl;
		cout << "by Nishant Sivakumar, http://www.codeproject.com/tips/CSMTPConnection2.asp" << endl;
		return 0;
	}

	//Need to call this COM API method for CMimeMessage to work
	CoInitialize(0);

	//create the message object
	CMimeMessage msg;
	msg.SetSender(argv[2]);
	msg.SetSenderName(argv[1]);
	msg.AddRecipient(argv[3]);
	msg.SetSubject(argv[4]);

	//determine message body via message flag
	string flag = argv[5];
	//if message given on command line
	if(flag == "-t")
	{
		//use as is
		msg.AddText(argv[6]);
	}
	//if message is in a file
	if(flag == "-f")
	{
		//open file for reading
		ifstream ins;
		ins.open(argv[6]);
		if( !ins ) 
		{
			cerr << "Error opening the message file." << endl;
			return 1;
		}
		else
		{
			int length;
			char *msgTxt;
					
			//get length of file for amount of text to read
			ins.seekg (0, ios::end);
			length = ins.tellg();
			ins.seekg (0, ios::beg);
			
			//allocate memory for text storage
			msgTxt = new char [length];

			//read in text as a block of data, then close file
			ins.read(msgTxt,length);
			ins.close();
			//now add text to email message
			msg.AddText(msgTxt);
		}
	}
	//msg.AttachFile("some file path");

	CSMTPConnection2 conn;
	//You need to specify the domain name of the recipient email address
	//Parse out domain name from recipient email
	string temp = argv[3];
	size_t pos = temp.find("@",0);
	temp = temp.substr(pos+1,100);
	const char *domain = temp.c_str();
	
	//Try send mail via mail server of domain, specified by DNS MX record
	if(conn.Connect(domain))
	{
		if( conn.SendMessage(msg) == TRUE )
		{
			cout << endl;
			cout << "Mail sent successfully." << endl;
		}
		else
		{
			cout << endl;
			cout << "Error: Mail could not be sent." << endl;
		}
		conn.Disconnect();    
	}
	return 0;
}

